package lab.pkg6;

public class Student2 {

    private String name;
    private int id;
    private double cgpa;

    // Default constructor
    public Student2() {
        this.name = "Arifen";
        this.id = 5284;
        this.cgpa = 3.72;
    }
    

    // Parameterized constructor
    public Student2(String name, int id, double cgpa) {
        this.name = name;
        this.id = id;
        this.cgpa = cgpa;
    }

    // Display method
    public void display() {
        System.out.println("Name: " + this.name);
        System.out.println("ID: " + this.id);
        System.out.println("CGPA: " + this.cgpa);
        System.out.println("\n");

    }

    public static void main(String[] args) {
        // Create two objects using default constructor
        Student2 s1 = new Student2();
        Student2 s2 = new Student2();

        // Create two objects using parameterized constructor
        Student2 s3 = new Student2("Akib", 598, 3.7);
        Student2 s4 = new Student2("Rahim", 456, 3.9);

        // Display all the student list
        s1.display();
        s2.display();
        s3.display();
        s4.display();
    }
}
