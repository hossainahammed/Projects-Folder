
package lab.pkg6;

import java.util.Scanner;


public class Student {
    private String name;
    private int id;
    private double cgpa;
    
    public void insert(String name, int id, double cgpa){
        this.name=name;
        this.id=id;
        this.cgpa=cgpa;
    }
    public void display(){
        System.out.println("Name: "+this.name);
        System.out.println("ID: "+this.id);
        System.out.println("CGPA: "+this.cgpa);
    }
    
    public void setData(String newname, int newid, double newcgpa){
        this.name=newname;
        this.id=newid;
        this.cgpa=newcgpa;
    }
    public void getData(){
        System.out.println("Name after editing: "+this.name);
        System.out.println("ID after editing: "+this.id);
        System.out.println("CGPA after editing: "+this.cgpa);
    }
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        
        System.out.print("Enter the number of students: ");
        int i,n=scan.nextInt();
        Student[] arr=new Student[n];
        
        for(i=0; i<n; i++){
            arr[i]=new Student();
            scan.nextLine();
            System.out.print("Enter the name of the student: ");
            String name=scan.nextLine();
            System.out.print("Enter the ID of the student: ");
            int id=scan.nextInt();
            System.out.print("Enter the CGPA of the student: ");
            double cgpa=scan.nextDouble();
            
            arr[i].insert(name, id, cgpa);
        }
        
        for(i=0; i<n; i++){
            arr[i].display();
        }
        
        
        System.out.print("Enter the ID you want to search: ");
        int flag=0,s=scan.nextInt();
        
        for(i=0; i<n; i++){
            if(s==arr[i].id){
                flag=0;
                break;
            }
            else{
                flag++;
            }
        }
        
        if(flag==0){
            arr[i].display();
        }
        else{
            System.out.println("Not Found");
        }
        
        
        System.out.print("Enter the ID you want to Edit: ");
        int f=0,e=scan.nextInt();
        
        for(i=0; i<n; i++){
            if(e==arr[i].id){
                f=0;
                break;
            }
            else{
                f++;
            }
        }
        
        if(f==0){
            scan.nextLine();
            System.out.print("Enter new name: ");
            String newname=scan.nextLine();
            System.out.print("Enter new ID: ");
            int newid=scan.nextInt();
            System.out.print("Enter new CGPA: ");
            double newcgpa=scan.nextDouble();
            arr[i].setData(newname, newid, newcgpa);
            arr[i].getData();
        }
        else{
            System.out.println("Not Found");
        }
        
        System.out.print("Enter the ID you want to delete: ");
        int flag1=0,d=scan.nextInt();
        
        for(i=0; i<n; i++){
            if(d==arr[i].id){
                flag1=0;
                break;
            }
            else{
                flag1++;
            }
        }
        
        if(flag1==0){
            arr[i]=null;
        }
        else{
            System.out.println("Not Found");
        }
        
        System.out.println("Info after deletion: ");
        for(i=0; i<n; i++){
            if(arr[i]!=null){
                arr[i].display();
            }
        }
    }
}


