
package lab.pkg6;

import java.util.Scanner;

public class Student1 {
    private String name;
    private int id;
    private double cgpa;

    public Student1(String name, int id, double cgpa) {
        this.name = name;
        this.id = id;
        this.cgpa = cgpa;
    }

    public void display() {
        System.out.println("Name: " + name + ", ID: " + id + ", CGPA: " + cgpa);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of students: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // consume the newline character
        Student1[] students = new Student1[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for student " + (i+1) + ": ");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("ID: ");
            int id = scanner.nextInt();
            System.out.print("CGPA: ");
            double cgpa = scanner.nextDouble();
            scanner.nextLine(); // consume the newline character
            students[i] = new Student1(name, id, cgpa);
        }
        System.out.println("Student List:");
        for (int i=0;i<n;i++) {
            students[i].display();
        }
    }
}
