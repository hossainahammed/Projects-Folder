public class Personal_info {
    public static void main(String[] args) {

        String name = "Chayon Biswas";
        int id = 5767;
        String address ="Manikganj";
        String department = "CSE";
        String game = "Ludo";
        System.out.println("Name          : "+name);
        System.out.println("ID            : "+id);
        System.out.println("Address       : "+address);
        System.out.println("Department    : "+department);
        System.out.println("Faborite game : "+game);

    }
}
