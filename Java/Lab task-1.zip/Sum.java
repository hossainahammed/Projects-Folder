public class Sum {
    public static void main(String[] args) {
        int a=30;
        int b=20;
        int sum=a+b;
        System.out.print("Sum of a+b = "+sum);
    }
}
