public class Equation {
    public static void main(String[] args) {
        int A = 5, B = 6, C = 7, D = 8;

        int result1 = A * B - C * D;
        int result2 = 2 * A - B + 3 * D;
        int result3 = ((A*A)+(B*B))-((C*C)+(D*D));
        int result4 = ((A*A*A)+B)-(C*C);

        System.out.println("Result 1: " + result1);
        System.out.println("Result 2:  " + result2);
        System.out.println("Result 3: " + result3);
        System.out.println("Result 4:  " + result4);
    }
}

