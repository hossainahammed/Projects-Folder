public class Name_variabl {

        public static void main(String[] args) {
            String name = "Chayon Biswas";
            System.out.println("My name is: " + name);
        }
}
