package lab.pkg3;

import java.util.Scanner;

public class problem03 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("How many Studetns's CGPA you want to insert? ");
        int n = input.nextInt();
        float[] array = new float[n];
        System.out.println("Enter " + n + " value");
        for (int i = 0; i < n; i++) {
            array[i] = input.nextFloat();
        }
        float min = array[0];
        float max = array[0];

        for (int i = 0; i < n; i++) {
            if (array[i] < min) {
                min = array[i];
            }
            if (array[i] > max) {
                max = array[i];
            }
        }
        System.out.println("Largest CGPA = " + max);
        System.out.println("Smallest CGPA = " + min);

    }
}
