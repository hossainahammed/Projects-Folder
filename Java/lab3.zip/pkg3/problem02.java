package lab.pkg3;

import java.util.Scanner;

public class problem02 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("How many number do you insert");
        int n = input.nextInt();
        int[] array = new int[n];
        System.out.println("Enter " + n + " value");
        for (int i = 0; i < array.length; i++) {
            array[i] = input.nextInt();
        }
        System.out.println("Enter element do you want");

        int terget = input.nextInt();
        int position = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == terget) {
                position = i;
                break;
            }

        }
        if (position != -1) {
            System.out.println(terget + " is found at index " + position);
        } else {
            System.out.println(terget + " is not found in the Array");
        }

    }

}
