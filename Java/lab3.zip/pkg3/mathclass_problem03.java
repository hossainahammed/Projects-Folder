
package lab.pkg3;


public class mathclass_problem03 {
    public static void main(String[] args) {
        for(int i=0;i<5;i++){
            int random=(int)(Math.random()*200+0);
           System.out.println(random); 
        }
        
    }
}
