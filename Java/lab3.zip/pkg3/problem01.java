package lab.pkg3;

import java.util.Arrays;
import java.util.Scanner;

public class problem01 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("How many Numbers you want to insert? ");
        int n = input.nextInt();

        int[] array = new int[n];
        for (int i = 0; i < n; i++) {
            array[i] = input.nextInt();

        }
        Arrays.sort(array);
        for (int i = 0; i < n; i++) {
            System.out.println(array[i]);
        }
        
    }
}
