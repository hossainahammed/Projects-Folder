
package lab.pkg3;

import java.util.Scanner;


public class mathclass_problem05 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the radious of the circle");
        double radious=input.nextDouble();
        double area=Math.PI*Math.pow(radious,2);
        System.out.println("The area of the circle is "+area);
    }
}
