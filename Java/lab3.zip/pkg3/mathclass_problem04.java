
package lab.pkg3;
import java.util.Scanner;

public class mathclass_problem04 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter your N value: ");
        int n=input.nextInt();
        for(int i=0;i<n;i++){
        double power=Math.pow(2,i);
            System.out.println("2^"+i+"="+power);
    }
        
    }
}
