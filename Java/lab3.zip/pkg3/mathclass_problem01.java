package lab.pkg3;

public class mathclass_problem01 {

    public static void main(String[] args) {
        System.out.println(Math.abs(-1));
        System.out.println(Math.floor(1.5));
        System.out.println(Math.ceil(1.5));
        System.out.println(Math.round(1.5));
        System.out.println(Math.sqrt(9));
    }
}
