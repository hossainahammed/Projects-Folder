package lab.pkg3;

import java.util.Scanner;

public class problem04 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("How many number do you insert in N1");
        int N1 = input.nextInt();
        int[] array1 = new int[N1];
        System.out.println("Enter " + N1 + " array elements");
        for (int i = 0; i < N1; i++) {
            array1[i] = input.nextInt();
        }

        System.out.println("How many number do you insert in N2");
        int N2 = input.nextInt();
        int[] array2 = new int[N2];
        System.out.println("Enter " + N2 + " array elements");
        for (int i = 0; i < N2; i++) {
            array2[i] = input.nextInt();
        }
        int[] array3 = new int[array1.length + array2.length];
        for (int i = 0; i < array1.length; i++) {
            array3[i] = array1[i];
        }
        for (int i = 0; i < array2.length; i++) {
            array3[i + array1.length] = array2[i];
        }
        for (int i = 0; i < array3.length; i++) {
            System.out.println(array3[i]);
        }

    }
}
