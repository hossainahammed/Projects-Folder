package lab.pkg3;

public class mathclass_problem02 {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = 30;
        int max = Math.max(a, Math.max(b, c));
        int min = Math.min(a, Math.min(b, c));
        System.out.println("Maximum value is: " + max);
        System.out.println("Minimum value is: " + min);
    }
}
