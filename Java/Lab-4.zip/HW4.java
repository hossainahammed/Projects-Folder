
package lab4;
//import java.util.Arrays;
import java.util.*;
public class HW4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String[] names={"Babul","Kamal","Alam","Antara"};
        
        Arrays.sort(names);
        
        for (String name:names) {
            System.out.println(name);
            
        }
    }
    
}
