//Input Three Strings and find out which one is Longer.
package lab4;
import java.util.Scanner;

public class HW2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first string: ");
        String str1 = scanner.nextLine();

        System.out.print("Enter second string: ");
        String str2 = scanner.nextLine();

        System.out.print("Enter third string: ");
        String str3 = scanner.nextLine();

        if (str1.compareTo(str2) > 0 && str1.compareTo(str3)>0){
            System.out.println("String 1 is greatest");
        }
        else if (str2.compareTo(str1) > 0 && str2.compareTo(str3) >0){
            System.out.println("String 2 is greatest");
        }else
            System.out.println("String 3 is greatest");        
    }
}

