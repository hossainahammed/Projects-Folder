/*
Create the Mobile Class. Then create N number of objects of this class. Take User input 
for the number of objects and the instance variables [Array of Objects].

*/
package lab4;

import java.util.*;
public class Mobile {
    private String modelName;
    private String brand;
    private int code;
    private double price;
    
    public void setmodelName(String modelName){
        this.modelName = modelName;
    }
    public void setBrand(String brand){
        this.brand=brand;
    }
    public void setCode(int code){
        this.code=code;
    }
    public void setPrice(double price){
        this.price=price;
    }
    public String getmodelName(){
        return modelName;
    }
    public String getBrand(){
        return brand;
    }
    public int getCode(){
        return code;
    }
    public double getPrice(){
        return price;
    }
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("How many mobile information you want:");
        int n=sc.nextInt();
        Mobile[] obj=new Mobile[n];
        
        sc.nextLine();
        
        for (int i = 0; i < n; i++) {
            obj[i]=new Mobile();
            System.out.println("Number of Mobile-"+(i+1)+":");
            System.out.print("Model name:");
            String modelName=sc.nextLine();
            System.out.print("Brand: ");
            String brand=sc.nextLine();
            System.out.print("Code: ");
            int code=sc.nextInt();
            System.out.print("Price: ");
            double price=sc.nextDouble();
            
            sc.nextLine();
            obj[i].setmodelName(modelName);
            obj[i].setBrand(brand);
            obj[i].setCode(code);
            obj[i].setPrice(price);
        }
        sc.nextLine();
        for (int i = 0; i < n; i++) {
            System.out.println("Mobile "+(i+1)+"Information: ");
            System.out.println("Model Name: "+obj[i].getmodelName());
            System.out.println("Model Name: "+obj[i].getBrand());
            System.out.println("Model Name: "+obj[i].getCode());
            System.out.println("Model Name: "+obj[i].getPrice());
            System.out.println("\n");
            
        }
    }
    
}
