//Input Three Strings and find out which two Strings are Equal.
package lab4;

import java.util.*;
public class HW3 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        
        System.out.print("Enter first string: ");
        String str1 = sc.nextLine();

        System.out.print("Enter second string: ");
        String str2 = sc.nextLine();

        System.out.print("Enter third string: ");
        String str3 = sc.nextLine();
        
        if(str1.equals(str2))
            System.out.println("String – 1 is Equals to String- 2");
        else if(str1.equals(str3))
            System.out.println("String – 1 is Equals to String- 3");
        else
            System.out.println("String – 2 is Equals to String- 3");
    }
    
}
