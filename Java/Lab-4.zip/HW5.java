/*
 Input two Strings and convert them in both Lower case and Upper case
 */
package lab4;

import java.util.*;
public class HW5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String st1=sc.nextLine();
        String st2=sc.nextLine();
        System.out.println("Lower Case:");
        System.out.println(st1.toLowerCase());
        System.out.println(st2.toLowerCase());
        System.out.println("Upper Case:");
        System.out.println(st1.toUpperCase());
        System.out.println(st2.toUpperCase());
    }
    
}
