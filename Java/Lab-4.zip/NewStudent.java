
package lab4;

import java.util.Scanner;

public class NewStudent {
    private String name;
    private int age;
    private double gpa;

    
    
    /*public void Student(String name, int age, double gpa) {
        this.name = name;
        this.age = age;
        this.gpa = gpa;
    }*/

    // Getters and setters for the instance variables
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int n = scanner.nextInt();
        
        scanner.nextLine();

        NewStudent[] student = new NewStudent[n];

        for (int i = 0; i < n; i++) {
            student[i]=new NewStudent();
            System.out.println("Enter the details of student #" + (i+1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Age: ");
            int age = scanner.nextInt();
            System.out.print("GPA: ");
            double gpa = scanner.nextDouble();
            
            scanner.nextLine();
            
            student[i].setName(name);
            student[i].setAge(age);
            student[i].setGpa(gpa);
            
            /*System.out.println("Information of Student-"+i);
            System.out.println("Name: "+student[i].getName());
            System.out.println("Name: "+student[i].getAge());
            System.out.println("Name: "+student[i].getGpa());*/
            

            //student[i] = new Student(name, age, gpa);
        }

        // Display the details of all the students
        for (int i = 0; i < n; i++) {
            System.out.println("Information of Student-"+i);
            //scanner.nextLine();
            System.out.println("Name: "+student[i].getName());
            System.out.println("Name: "+student[i].getAge());
            System.out.println("Name: "+student[i].getGpa());
            
        }
    }
}

