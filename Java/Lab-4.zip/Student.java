
package lab4;

import java.util.*;
public class Student {
    private String name;
    private int id;
    private double cgpa;
    
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Student st1=new Student();
        
        st1.name=sc.nextLine();
        st1.id=sc.nextInt();
        st1.cgpa=sc.nextDouble();
        
        System.out.println("Name of Student-1: "+st1.name);
        System.out.println("ID of Student-1: "+st1.id);
        System.out.println("CGPA of Student-1: "+st1.cgpa);
        
        
        Student st2=new Student();
        
        sc.nextLine();
        
        st2.name=sc.nextLine();
        st2.id=sc.nextInt();
        st2.cgpa=sc.nextDouble();
        
        System.out.println("Name of Student-2: "+st2.name);
        System.out.println("ID of Student-2: "+st2.id);
        System.out.println("CGPA of Student-2: "+st2.cgpa);
        
        
    }
    
}
