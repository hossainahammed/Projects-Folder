//Concat(Merge) Three Strings together.
package lab4;

import java.util.*;
public class HW1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("String-1:");
        String st1=sc.nextLine();
        System.out.print("String-2:");
        String st2=sc.nextLine();
        System.out.print("String-3:");
        String st3=sc.nextLine();
        
        String result=st1.concat(st2).concat(st3);
        String result2=st1.concat(st2);
        System.out.println(result);
        System.out.println(result2);
        
    }
    
}
