
package Lab2;

import java.util.Scanner;
public class HW1 {
    public static void main(String[]args){
        Scanner input=new Scanner(System.in);
        int a,b,sum;
        a=input.nextInt();
        b=input.nextInt();
        
        sum=a+b;
        
        System.out.println(sum);
    }
    
}
