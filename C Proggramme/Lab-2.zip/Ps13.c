#include<stdio.h>
int main(){
float A = 7.55, B = 7.56, sum;
    sum = A + B;
    printf("%.2f",sum);
return 0;
}