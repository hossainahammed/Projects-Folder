#include<stdio.h>
int main(){
    printf("Hossain Ahammed");
 return 0;
} 