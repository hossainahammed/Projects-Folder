#include<stdio.h>
int main(){
int a = 1, b = 2, c = 3, d =4 , e = 5, f = 6, sum1, sum2, sum3, sum;
 sum1 = c + b;
 sum2 = f + d;
 sum3 = e + a;
 sum = sum1 + sum2 + sum3;
    printf("%d+%d=%d\n%d+%d=%d\n%d+%d=%d\n%d+%d+%d=%d", c,b,sum1,f,d,sum2,e,a,sum3,sum1,sum2,sum3,sum);
return 0;
}
