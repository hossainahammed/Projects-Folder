#include<stdio.h>
int main(){
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    int largest=0;
    int smallest=0;
    if(a>b && a>c && a>d){
        largest=a;
    }else if(b>a && b>c && b>d){
        largest=b;
    }else if(c>a && c>b && c>d){
        largest=c;
    }else{
        largest=d;
    }

    if(a<b && a<c && a<d){
        smallest=a;
    }else if(b<a && b<c && b<d){
        smallest=b;
    }else if(c<a && c<b && c<d){
        smallest=c;
    }else{
        smallest=d;
    }
    int sum=largest+smallest;
    if(sum>5 && sum<9){
        printf("Ground\n");
    }else if(sum>=9){
        printf("Roof\n");
    }else if(sum<6){
        printf("Too small\n");
    }
    return 0;

}
