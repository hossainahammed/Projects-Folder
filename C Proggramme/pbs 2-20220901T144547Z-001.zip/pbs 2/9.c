#include <stdio.h>
int  main()
{
   char a;
    int b;
    printf("What is your name?\n");
    scanf("%s",&a);
    printf("What is your id?\n");
    scanf("%d ",&b);
    printf("Thank you\n");
    return 0;
}
