#include <stdio.h>
int  main()
{
float a,b,c,d,sum,n;
    printf("Enter the value of a&b&c&d\n");
    scanf("%f %f %f %f",&a,&b,&c,&d);
    sum=a+b+c+d;
    n=sum/2;
    printf("%f \n",n-1);
    return 0;
}
