#include <stdio.h>
int main()
{
    printf("1.Biriyani \n 2.Burger\n 3.Pizza");
    return 0;
}
