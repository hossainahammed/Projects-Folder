#include <stdio.h>
int  main()
{
int a,b;
    printf("Enter the value of a&b\n");
    scanf("%d %d",&a,&b);
    printf("%d \n",a+b);
    if(a+b>5)
    {
    printf("Well done");
    }
    else {
        printf("Try again later");
    }
    return 0;
}
