#include <stdio.h>
int  main()
{
int a,b;
    printf("Enter the value of a&b\n");
    scanf("%d %d",&a,&b);
    printf("%d \n",a+b);
    return 0;
}
