#include <stdio.h>
int  main()
{
 float a,b,sum,c,d;
    scanf("%f %f",&a,&b);
    sum=a+b;
    c=sum/2;
    printf("%f\n", (sum-c)*3);
    return 0;
}
