#include <stdio.h>
int  main()
{
int a,b,div;
    printf("Enter the value of a&b\n");
    scanf("%d %d",&a,&b);
    div=a%b;
    printf("%d \n",div);
    return 0;
}
